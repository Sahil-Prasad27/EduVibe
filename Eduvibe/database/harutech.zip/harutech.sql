-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2024 at 05:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `harutech`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `book_name` varchar(255) NOT NULL,
  `book_file` varchar(255) NOT NULL,
  `file_type` enum('pdf','word','ppt') NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `book_name`, `book_file`, `file_type`, `image`) VALUES
(11, 'The Trial Author Franz Kafka', '2. The Trial Author Franz Kafka.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.51.38 PM (2).jpeg'),
(12, 'Basic Introduction into Algorithms and Data Structures Author Frauke Liers', '1. Basic Introduction into Algorithms and Data Structures Author Frauke Liers.pdf', 'pdf', 'images/algorithms-books.webp'),
(13, ' Treasure Island Author Robert Louis Stevenson-compressed', '2. Treasure Island Author Robert Louis Stevenson-compressed.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.41.55 PM.jpeg'),
(15, 'Little Women Author Louisa May Alcott-compressed', '3. Little Women Author Louisa May Alcott-compressed.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.51.40 PM (1).jpeg'),
(16, 'Madame Bovary Author Gustave Flaubert', '3. Madame Bovary Author Gustave Flaubert.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.25.25 PM (1).jpeg'),
(17, 'Anne of Green Gables Author L. M. Montgomery', '4. Anne of Green Gables Author L. M. Montgomery.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.51.38 PM (1).jpeg'),
(18, 'The Time Machine Author H. G. Wells', '4. The Time Machine Author H. G. Wells.pdf', 'pdf', 'images/download.jpg'),
(19, 'Anne\'s House of Dreams Author L. M. Montgomery-compressed', '5. Anne\'s House of Dreams Author L. M. Montgomery-compressed.pdf', 'pdf', 'images/OIP.jpeg'),
(20, ' Anne of the Island Author L. M. Montgomery-compressed', '6. Anne of the Island Author L. M. Montgomery-compressed.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.41.59 PM.jpeg'),
(21, 'A Room with a View Author E. M. Forster', '7. A Room with a View Author E. M. Forster.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.25.25 PM.jpeg'),
(22, 'Brave New World Author Aldous Huxley backup', '7. Brave New World Author Aldous Huxley backup.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.51.39 PM.jpeg'),
(23, 'The Call of the Wild Author Jack London', '7. The Call of the Wild Author Jack London.pdf', 'pdf', 'images/download.jpeg'),
(24, ' Pride and Prejudice Author Jane Austen-compressed', '8. Pride and Prejudice Author Jane Austen-compressed.pdf', 'pdf', 'images/download (1).jpeg'),
(25, 'INDIAN_AWLIYAS_PDF', 'INDIAN_AWLIYAS_PDF.pdf', 'pdf', 'images/indian_awliyas.jpg'),
(26, 'think-and-grow-rich-napoleon-hill', 'think-and-grow-rich-napoleon-hill.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.25.26 PM (1).jpeg'),
(27, 'Jane Eyre Author Charlotte Brontë', '9. Jane Eyre Author Charlotte Brontë.pdf', 'pdf', 'images/download (2).jpeg'),
(28, 'Andrew S. Tanenbaum - Computer Networks', 'Andrew S. Tanenbaum - Computer Networks.pdf', 'pdf', 'images/download (3).jpeg'),
(29, 'the-hound-of-the-baskervilles-arthur-conan-doyle', 'the-hound-of-the-baskervilles-arthur-conan-doyle.pdf', 'pdf', 'images/WhatsApp Image 2024-08-30 at 7.25.26 PM.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `stickers`
--

CREATE TABLE `stickers` (
  `sticker_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cost` int(11) NOT NULL,
  `image_url` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stickers`
--

INSERT INTO `stickers` (`sticker_id`, `name`, `cost`, `image_url`) VALUES
(19, 'Bronze', 50, 0x506963736172745f32342d30382d33315f30312d32352d35352d3539392e706e67),
(20, 'silver', 100, 0x506963736172745f32342d30382d33315f30312d32362d34392d3137332e706e67),
(21, 'Gold', 500, 0x506963736172745f32342d30382d33315f30312d33312d32362d3739352e706e67),
(22, 'Platinum', 1000, 0x506963736172745f32342d30382d33315f30312d34302d34372d3134392e706e67),
(23, 'Ruby', 10000, 0x506963736172745f32342d30382d33315f30312d33352d30372d3632332e706e67),
(24, 'Sapphire', 1000000, 0x506963736172745f32342d30382d33315f30312d33332d33322d3432352e706e67);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` int(11) NOT NULL,
  `dob` date NOT NULL,
  `type` varchar(255) NOT NULL,
  `gold_coins` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `password`, `gender`, `email`, `mobile`, `dob`, `type`, `gold_coins`) VALUES
(3, 'Piku', '25f9e794323b453885f5181f1b624d0b', 'Male', 'piku123@gmail.com', 123456789, '2024-08-06', 'user', 0),
(4, 'shail', '25f9e794323b453885f5181f1b624d0b', 'Male', 'shail123@gmail.com', 123456789, '2024-08-13', 'admin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_activity`
--

CREATE TABLE `user_activity` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `time_spent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_activity`
--

INSERT INTO `user_activity` (`id`, `user_id`, `visit_date`, `time_spent`) VALUES
(1, 3, '2024-08-31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_stickers`
--

CREATE TABLE `user_stickers` (
  `user_id` int(11) NOT NULL,
  `sticker_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stickers`
--
ALTER TABLE `stickers`
  ADD PRIMARY KEY (`sticker_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_activity`
--
ALTER TABLE `user_activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_stickers`
--
ALTER TABLE `user_stickers`
  ADD PRIMARY KEY (`user_id`,`sticker_id`),
  ADD KEY `sticker_id` (`sticker_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `stickers`
--
ALTER TABLE `stickers`
  MODIFY `sticker_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_activity`
--
ALTER TABLE `user_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_activity`
--
ALTER TABLE `user_activity`
  ADD CONSTRAINT `user_activity_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `user_stickers`
--
ALTER TABLE `user_stickers`
  ADD CONSTRAINT `user_stickers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_stickers_ibfk_2` FOREIGN KEY (`sticker_id`) REFERENCES `stickers` (`sticker_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
